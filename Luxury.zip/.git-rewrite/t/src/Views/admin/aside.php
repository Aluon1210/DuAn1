<aside class="admin-sidebar">
      <nav class="admin-menu">
        <ul>
          <li><a href="<?php echo ROOT_URL; ?>admin" class="menu-item">Tổng quan</a></li>
          <li><a href="#" class="menu-item">Người dùng</a></li>
          <li><a href="<?php echo ROOT_URL; ?>admin/products" class="menu-item active">Sản phẩm</a></li>
          <li><a href="#" class="menu-item">Đơn hàng</a></li>
          <li><a href="#" class="menu-item">Danh mục</a></li>
          <li><a href="#" class="menu-item">Bình luận</a></li>
          <li><a href="#" class="menu-item">Thống kê</a></li>
        </ul>
      </nav>
    </aside>