<?php

namespace Controllers;
use Core\Controller; // Sử dụng Controller cơ sở


class DashboardControlller extends Controller {

    
        
}
