<?php
return [
    'smtp' => [
        'enabled' => true,
        'host' => 'smtp.gmail.com',
        'port' => 587,
        'username' => 'duongthanhcong22112006@gmail.com',
        'password' => 'ojlh qtbs zoup zpgb',
        'encryption' => 'tls',
        'from_email' => 'duongthanhcong22112006@gmail.com',
        'from_name' => 'Luxury Fashion',
        'timeout' => 30
    ]
];
